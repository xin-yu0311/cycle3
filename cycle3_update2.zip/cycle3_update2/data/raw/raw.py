import pandas as pd

df = pd.read_csv("data/raw/YRBS_2007.csv")

print(df.head())