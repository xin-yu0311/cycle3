import pandas as pd

# 1. 讀取原始資料
df = pd.read_csv("data/raw/YRBS_2007.csv")

# 2. 選取需要的欄位
cols = ["WhatIsYourSex", "SadOrHopeless"]
df_sub = df[cols].copy()

# 3. 移除缺失值
df_sub = df_sub.dropna(subset=cols)

# 4. 只保留有效編碼
# WhatIsYourSex:
# 1 = Female
# 2 = Male

# SadOrHopeless:
# 1 = Yes
# 2 = No

df_clean = df_sub[
    (df_sub["WhatIsYourSex"].isin([1, 2])) &
    (df_sub["SadOrHopeless"].isin([1, 2]))
].copy()

# 5. 性別重新命名
df_clean["Sex"] = df_clean["WhatIsYourSex"].map({
    1: "Female",
    2: "Male"
})

# 6. SadOrHopeless 重新編碼
# 1 = success / yes
# 0 = failure / no

df_clean["SadOrHopeless_binary"] = df_clean["SadOrHopeless"].map({
    1: 1,
    2: 0
})

# 7. 查看前幾筆資料
print(df_clean.head())

# 8. 查看資料數量
print(df_clean["Sex"].value_counts())

# 9. 查看 yes / no 數量
print(df_clean["SadOrHopeless_binary"].value_counts())

# 10. 存入 processed 資料夾
df_clean.to_csv(
    "data/processed/yrbs_sad_hopeless_recoded.csv",
    index=False
)

print("Processed data saved successfully!")